# THARCILLE FAHION HOUSE — Website Prototype

Static website preview for a student-led fashion design, production and retail business in Huye, Rwanda.

## Deploy with GitHub + Netlify

1. On GitHub, create a new repository (suggested name: `tharcille-fahion-house`).
2. Upload **index.html**, **netlify.toml**, and **README.md** to the **repository root** (not a nested folder), and commit changes to the `main` branch.
3. On Netlify, select **Add new project** > **Import an existing project** > **GitHub**.
4. Authorize access to the repository and select it.
5. Build command: leave empty. Publish directory: `.` (the repository root). Click **Deploy**.
6. Netlify assigns a temporary `.netlify.app` domain. You may configure a custom domain later.

## Important before launch

- This is a front-end prototype: the shop/cart use illustrative products and sample prices. Checkout is disabled.
- The enquiry form does not submit messages to a server. Configure an email/form backend first.
- External images and fonts require an internet connection; replace imagery with owned/licensed brand photos for production.
- The site has English content only; language switcher is a preview.
- Add authentic contact details and configure secure payments before accepting orders.

## Updating the site

Edit `index.html` and commit changes to `main`; Netlify automatically rebuilds the deployed site.
